import React, { useEffect, useState } from "react";
import {
  List,
  Row,
  Col,
  ConfigProvider,
  message,
  Button,
  Space,
  Skeleton,
  Pagination,
} from "antd";
import zhCN from "antd/lib/locale/zh_CN";

import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import Axios from "axios";
import servicePath from "../config/apiUrl";
export default function EmpList() {
  const [list, setList] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    Axios(servicePath.getEmp).then((res) => {
      setList(res.data);
      setIsLoading(false);
    });
  }, []);
  const gotoPage = () => { };
  return (
    <>
      <Row>
        <Col
          span={20}
          offset={2}
          style={{
            backgroundColor: "white",
            padding: "40px 50px 60px 50px",
            borderRadius: "25px",
          }}
        >
          <List
            header={
              <Row className="list-div">

                <Col span={4}>
                  <b>编号</b>
                </Col>
                <Col span={4}>
                  <b>雇员姓名</b>
                </Col>
                <Col span={6}>
                  <b>手机号</b>
                </Col>
                <Col span={4}>
                  <b>职位</b>
                </Col>
                <Col span={6}>
                  <b>操作</b>
                </Col>
              </Row>
            }
            bordered
            // style={{width:}}
            dataSource={list}
            renderItem={(item, index) => (
              <Skeleton loading={isLoading}>
                <List.Item>
                  <Row className="list-div">

                    <Col span={4}>
                      <b>{index + 1}</b>
                    </Col>
                    <Col span={4}>
                      <b>{item.empName}</b>
                    </Col>
                    <Col span={6}>
                      <b>{item.empPhone}</b>
                    </Col>
                    <Col span={4}>
                      <b>{item.empPost}</b>
                    </Col>

                    <Col span={6}>
                      <Space>
                        <Button
                          type="primary"
                          shape="round"
                          onClick={() => {
                            // updateArticle(item.id);
                          }}
                        >
                          <EditOutlined />
                          修改
                        </Button>
                        <Button
                          type="primary"
                          danger
                          shape="round"
                          onClick={() => {
                            // delArticle(item.goodsId);
                          }}
                        >
                          <DeleteOutlined />
                          删除
                        </Button>
                      </Space>
                    </Col>
                  </Row>
                </List.Item>
              </Skeleton>
            )}
          />

          <ConfigProvider locale={zhCN}>
            <Pagination
              total={100}
              hideOnSinglePage={true}
              showSizeChanger
              showQuickJumper
              showTotal={(total) => `共 ${total} 条`}
              onChange={(page, pageSize) => gotoPage(page, pageSize)}
              style={{ textAlign: "center", paddingTop: "50px" }}
            />
          </ConfigProvider>
        </Col>
      </Row>
    </>
  );
}
