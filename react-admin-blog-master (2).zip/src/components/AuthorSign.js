/*
 * @Author: lyc
 * @Date: 2020-12-03 19:20:14
 * @LastEditors: lyc
 * @LastEditTime: 2020-12-03 19:21:06
 * @Description: file content
 */

import React from "react"
export default () => (
  <>
    <center>
      <h2>Serira ma</h2>
      <h3>海纳百川，有容乃大</h3>
    </center>
  </>
)