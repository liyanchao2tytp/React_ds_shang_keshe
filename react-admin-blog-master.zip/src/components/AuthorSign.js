/*
 * @Author: lyc
 * @Date: 2020-12-03 19:20:14
 * @LastEditors: lyc
 * @LastEditTime: 2020-12-05 21:19:12
 * @Description: file content
 */

import React from "react"
export default () => (
  <>
    <center>
      <h2>Joey</h2>
      <h3>天上灯火，皆为星辰</h3>
    </center>
  </>
)